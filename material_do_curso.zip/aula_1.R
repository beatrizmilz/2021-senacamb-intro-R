# conceitos
# NA
# tipos de dados
# data frames
